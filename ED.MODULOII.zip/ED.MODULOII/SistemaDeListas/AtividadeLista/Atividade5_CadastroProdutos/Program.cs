using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        Console.WriteLine("========== ATIVIDADE 5 – SISTEMA DE CADASTRO DE PRODUTOS ==========\n");

        List<string> produtos = new List<string>();

        for (int i = 1; i <= 5; i++)
        {
            Console.Write("Digite o nome do produto " + i + ": ");
            string produto = Console.ReadLine();
            produtos.Add(produto);
        }

        Console.WriteLine();
        Console.WriteLine("=== PRODUTOS CADASTRADOS ===");

        foreach (string produto in produtos)
        {
            Console.WriteLine("- " + produto);
        }

        Console.WriteLine();
        Console.WriteLine("Pressione qualquer tecla para sair...");
        Console.ReadKey();
    }
}
