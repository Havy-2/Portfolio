using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        Console.WriteLine("========== ATIVIDADE 4 – REMOVENDO ELEMENTOS ==========\n");

        List<string> cidades = new List<string>();

        cidades.Add("Rio de Janeiro");
        cidades.Add("São Paulo");
        cidades.Add("Salvador");
        cidades.Add("Curitiba");

        cidades.Remove("Salvador");

        Console.WriteLine("Lista de cidades após remoção:");
        foreach (string cidade in cidades)
        {
            Console.WriteLine("- " + cidade);
        }

        Console.WriteLine();
        Console.WriteLine("Pressione qualquer tecla para sair...");
        Console.ReadKey();
    }
}
